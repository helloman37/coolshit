import xbmc, xbmcaddon, xbmcgui ,os, json, requests ,gzip, shutil
from resources.lib.modules import control

control.moderator()

def SetPVRSetting(PVRFolder):
	try:
		os.makedirs(os.path.join(PVRFolder))
	except:	pass
	
	PVRSetting = {	"epgPath": os.path.join(PVRFolder,"custom.xml"),
					"epgPathType":"0",
					"logoBaseUrl":"https://raw.githubusercontent.com/Apollo2000/TVLogos/raw/master/",
					"logoPathType":"1",
					"m3uPath": os.path.join(PVRFolder,"myaddon.m3u"),
					"m3uPathType":"0"}
	settingFile = xbmc.translatePath(os.path.join(PVRFolder, 'settings.xml'))
	xml = []
	xml.append("<settings>\n")
	for k, v in PVRSetting.iteritems():
		xml.append('\t<setting id="{0}" value="{1}" />\n'.format(k, v))
	xml.append("</settings>\n")
	outF = open(settingFile, 'wb')
	outF.write("".join(xml))
	outF.close()

def GetPVRAddon():
	PVRAddon = None
	if xbmc.getCondVisibility("System.HasAddon(pvr.iptvsimple)"):
		try:
			PVRAddon = xbmcaddon.Addon("pvr.iptvsimple")
		except:	pass
	return PVRAddon

def GetFile(url,file):
	try:
		os.remove(file)
	except:	pass
	response = requests.get(url, stream=True, verify=False)
	with open(file, 'wb') as out_file:
		shutil.copyfileobj(response.raw, out_file)
	del response

def SetFirstPVR():
	i = control.dialog.yesno(control.addon().getAddonInfo('name'),"Use TV Guide ?")
	if i == 0:
		control.addon().setSetting('pvr', "false")
	else:
		control.addon().setSetting('pvr', "true")

def runPVR():
	enable_iptvsimple  = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}'
	enable_pvrmanager  = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"pvrmanager.enabled", "value":true},"id":1}'

	if control.addon().getSetting('firstPVR')=="true":
		SetFirstPVR()

	if control.addon().getSetting('pvr')=="false":
		return

	PVRFolder = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'pvr.iptvsimple'))
	PVRAddon = GetPVRAddon()
	if not os.path.exists(PVRFolder) or PVRAddon is None:
		SetPVRSetting(PVRFolder)
	elif not PVRAddon.getSetting("m3uPath") == os.path.join(PVRFolder,"myaddon.m3u"):
		SetPVRSetting(PVRFolder)
	elif not PVRAddon.getSetting("logoBaseUrl") == "https://raw.githubusercontent.com/Apollo2000/TVLogos/raw/master/":
		SetPVRSetting(PVRFolder)

	GuideFile = xbmc.translatePath(os.path.join(PVRFolder, 'custom.xml'))
	M3UFile = xbmc.translatePath(os.path.join(PVRFolder, 'myaddon.m3u'))
	if control.addon().getSetting('pvrlite'):
		xmltvGzFile = xbmc.translatePath(os.path.join(PVRFolder, "utc.lite.xml.gz"))
	else:
		xmltvGzFile = xbmc.translatePath(os.path.join(PVRFolder, "utc.xml.gz"))

	xbmc.executebuiltin('Notification('+control.addon().getAddonInfo('name')+',"Please wait, loading TV Guide.", 5000,{0})'.format(os.path.join(control.addonPath ,"icon.png")))
	try:
		os.remove(xmltvGzFile)
	except:	pass
	if control.addon().getSetting('pvrlite'):
		GetFile("https://github.com/Apollo2000/TVGuide/raw/master/utc.lite.xml.gz", xmltvGzFile)
	else:
		GetFile("https://github.com/Apollo2000/TVGuide/raw/master/utc.xml.gz", xmltvGzFile)

	inF = gzip.open(xmltvGzFile, 'rb')
	outF = open(GuideFile, 'wb')
	outF.write(inF.read())
	inF.close()
	outF.close()

	GetFile("http://static."+control.addon().getSetting('domain')+"/myaddon.m3u",M3UFile)
	if not control.addon().getAddonInfo('id')=='program.apollo':
		with open(M3UFile, "rt") as fin:
			with open(M3UFile+"_tmp", "wt") as fout:
				for line in fin:
					fout.write(line.replace('program.apollo', control.addon().getAddonInfo('id')))
		fin.close
		fout.close
		os.remove(M3UFile)
		os.rename(M3UFile+"_tmp",M3UFile)

	xbmc.executeJSONRPC(enable_iptvsimple)
	xbmc.executeJSONRPC(enable_pvrmanager)
	xbmc.sleep(5)
	xbmc.executebuiltin('StopPVRManager')
	xbmc.executebuiltin('StartPVRManager')

	if control.addon().getSetting('firstPVR')=="true":
		control.addon().setSetting('firstPVR', "false")
		control.dialog.ok(control.addon().getAddonInfo('name'),"Please restart kodi for TV Guide to start")